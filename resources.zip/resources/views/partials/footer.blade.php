<footer class="py-2 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted common-text">Copyright &copy; {{ date('Y') }} {{ $content->com_name }}</div>
            <div class="common-text text-muted">
                Develop By -
                <a class="text-decoration-none" target="_blank" href="http://linktechbd.com/">Link-Up Technology Ltd.</a>
            </div>
        </div>
    </div>
</footer>